// External read/write against Minecraft's own process, using whatever
// privilege the caller (the Shizuku user-service process) was started
// with.
#include "external.h"
#include "target.h"

#include <android/log.h>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fstream>
#include <sstream>
#include <string>
#include <sys/uio.h>
#include <thread>
#include <unistd.h>
#include <unordered_map>
#include <unordered_set>

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "CC", __VA_ARGS__)

namespace cc {
namespace {

using namespace target;

struct Config {
    std::atomic<bool> aim{false};
    std::atomic<float> fov{30.f};
    std::atomic<float> speed{240.f};
    std::atomic<float> range{6.f};
    std::atomic<bool> hitbox{false};
    std::atomic<float> hbW{0.9f};
    std::atomic<float> hbH{1.9f};
};

Config g_cfg;
std::atomic<pid_t> g_pid{0};
std::atomic<uintptr_t> g_base{0};
std::atomic<bool> g_run{false};
std::thread g_worker;
std::unordered_map<uintptr_t, std::pair<float, float>> g_origBox;

bool have(size_t off) { return off != kUnset; }
float clampf(float v, float lo, float hi) { return std::min(std::max(v, lo), hi); }
float wrap180(float d) { while (d > 180.f) d -= 360.f; while (d < -180.f) d += 360.f; return d; }

pid_t findPid(const char* pkg) {
    DIR* d = opendir("/proc");
    if (!d) return 0;
    pid_t found = 0;
    dirent* e;
    while ((e = readdir(d))) {
        if (!isdigit(e->d_name[0])) continue;
        std::string path = std::string("/proc/") + e->d_name + "/cmdline";
        std::ifstream f(path, std::ios::binary);
        std::string cmd;
        std::getline(f, cmd, '\0');
        if (cmd == pkg) { found = atoi(e->d_name); break; }
    }
    closedir(d);
    return found;
}

uintptr_t findModuleBase(pid_t pid, const char* lib) {
    std::string path = "/proc/" + std::to_string(pid) + "/maps";
    std::ifstream f(path);
    std::string line;
    while (std::getline(f, line)) {
        if (line.find(lib) == std::string::npos) continue;
        auto dash = line.find('-');
        if (dash == std::string::npos) continue;
        return std::strtoull(line.substr(0, dash).c_str(), nullptr, 16);
    }
    return 0;
}

bool readMem(pid_t pid, uintptr_t a, void* out, size_t n) {
    if (!a) return false;
    iovec l{out, n}, r{reinterpret_cast<void*>(a), n};
    return process_vm_readv(pid, &l, 1, &r, 1, 0) == static_cast<ssize_t>(n);
}
template <class T> bool rd(pid_t pid, uintptr_t a, T& o) { return readMem(pid, a, &o, sizeof(T)); }

bool writeMem(pid_t pid, uintptr_t a, const void* p, size_t n) {
    iovec l{const_cast<void*>(p), n}, r{reinterpret_cast<void*>(a), n};
    return process_vm_writev(pid, &l, 1, &r, 1, 0) == static_cast<ssize_t>(n);
}
template <class T> bool wr(pid_t pid, uintptr_t a, const T& v) { return writeMem(pid, a, &v, sizeof(T)); }

bool resolveAddr(const Chain& c, pid_t pid, uintptr_t base, uintptr_t& out) {
    if (c.n <= 0) return false;
    uintptr_t a = base + c.v[0];
    for (int i = 1; i < c.n; i++) {
        uintptr_t p;
        if (!rd(pid, a, p) || !p) return false;
        a = p + c.v[i];
    }
    out = a;
    return true;
}

// Reads the position component pointer off an actor and returns the
// address of its first float (x). Two-step: actor -> component* -> floats.
// Separate from the generic Chain machinery above because it starts from
// a per-actor address, not the module base.
bool resolvePosAddr(pid_t pid, uintptr_t actorAddr, uintptr_t& out) {
    if (!have(kOffPosComponentPtr)) return false;
    uintptr_t comp;
    if (!rd(pid, actorAddr + kOffPosComponentPtr, comp) || !comp) return false;
    out = comp + kOffPosInComponent;
    return true;
}

struct Vec3 { float x, y, z; };

void restoreBoxes(pid_t pid) {
    for (auto& [p, wh] : g_origBox) { wr(pid, p + kOffHitW, wh.first); wr(pid, p + kOffHitH, wh.second); }
    g_origBox.clear();
}

void tick(pid_t pid, uintptr_t base, float dt) {
    uintptr_t lpAddr, listAddr;
    if (!resolveAddr(kLocalPlayer, pid, base, lpAddr) || !resolveAddr(kActorList, pid, base, listAddr)) {
        return;  // roots unresolved; nothing to do yet
    }
    uintptr_t lp = 0;
    uintptr_t lpPosAddr;
    Vec3 lpos;
    if (!rd(pid, lpAddr, lp) || !lp) return;
    if (!resolvePosAddr(pid, lp, lpPosAddr) || !rd(pid, lpPosAddr, lpos)) return;
    Vec3 eye = lpos;
    if (!kPosIsEye) eye.y += kEyeHeight;

    uintptr_t b = 0, e = 0;
    if (!rd(pid, listAddr, b) || !rd(pid, listAddr + 8, e) || e < b) return;
    size_t count = (e - b) / sizeof(uintptr_t);
    if (count > 1024) return;

    bool aimOn = g_cfg.aim.load();
    bool hbOn = g_cfg.hitbox.load();
    float curYaw = 0, curPitch = 0;
    bool canAim = aimOn && have(kOffYaw) && have(kOffPitch) &&
                  rd(pid, lp + kOffYaw, curYaw) && rd(pid, lp + kOffPitch, curPitch);
    bool canBox = hbOn && have(kOffHitW) && have(kOffHitH);
    float fov = g_cfg.fov.load(), speed = g_cfg.speed.load(), range = g_cfg.range.load();
    float hbW = g_cfg.hbW.load(), hbH = g_cfg.hbH.load();

    std::unordered_set<uintptr_t> seen;
    uintptr_t best = 0;
    float bestErr = 1e9f, bestYaw = 0, bestPitch = 0;

    for (size_t i = 0; i < count; i++) {
        uintptr_t a;
        if (!rd(pid, b + i * sizeof(uintptr_t), a) || !a || a == lp) continue;
        uintptr_t posAddr;
        Vec3 p;
        if (!resolvePosAddr(pid, a, posAddr) || !rd(pid, posAddr, p) || !std::isfinite(p.x + p.y + p.z)) continue;
        if (have(kOffActorType) && kPlayerTypeId >= 0) {
            int32_t t;
            if (!rd(pid, a + kOffActorType, t) || t != kPlayerTypeId) continue;
        }
        float dx = p.x - lpos.x, dy = p.y - lpos.y, dz = p.z - lpos.z;
        float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
        seen.insert(a);

        if (canBox && dist <= 16.f) {
            if (!g_origBox.count(a)) {
                float w, h;
                if (rd(pid, a + kOffHitW, w) && rd(pid, a + kOffHitH, h)) g_origBox[a] = {w, h};
            }
            if (g_origBox.count(a)) { wr(pid, a + kOffHitW, hbW); wr(pid, a + kOffHitH, hbH); }
        }

        if (canAim && dist <= range) {
            Vec3 aimPt = p;
            if (!kPosIsEye) aimPt.y += kEyeHeight;
            float tx = aimPt.x - eye.x, ty = aimPt.y - eye.y, tz = aimPt.z - eye.z;
            float hd = std::sqrt(tx * tx + tz * tz);
            if (hd < 1e-4f) continue;
            float yaw = std::atan2(-tx, tz) * 57.29578f;
            float pitch = -std::atan2(ty, hd) * 57.29578f;
            float err = std::sqrt(wrap180(yaw - curYaw) * wrap180(yaw - curYaw) + (pitch - curPitch) * (pitch - curPitch));
            if (err <= fov && err < bestErr) { bestErr = err; best = a; bestYaw = yaw; bestPitch = pitch; }
        }
    }

    for (auto it = g_origBox.begin(); it != g_origBox.end();)
        it = seen.count(it->first) ? std::next(it) : g_origBox.erase(it);

    if (best) {
        float step = speed * dt;
        float ny = curYaw + clampf(wrap180(bestYaw - curYaw), -step, step);
        float np = curPitch + clampf(bestPitch - curPitch, -step, step);
        wr(pid, lp + kOffYaw, ny);
        wr(pid, lp + kOffPitch, np);
    }
}

void workerLoop() {
    using clock = std::chrono::steady_clock;
    auto last = clock::now();
    while (g_run.load()) {
        pid_t pid = g_pid.load();
        uintptr_t base = g_base.load();
        if (pid && base) {
            auto now = clock::now();
            float dt = clampf(std::chrono::duration<float>(now - last).count(), 0.001f, 0.1f);
            last = now;
            if (kill(pid, 0) != 0) { g_pid = 0; g_base = 0; continue; }
            tick(pid, base, dt);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
}

} // namespace

bool attach() {
    pid_t pid = findPid(kPackage);
    if (!pid) { LOG("process %s not found", kPackage); return false; }
    uintptr_t base = findModuleBase(pid, kGameLib);
    if (!base) { LOG("module %s not found in pid %d", kGameLib, pid); return false; }
    g_pid = pid;
    g_base = base;
    LOG("attached pid=%d base=0x%lx", pid, static_cast<unsigned long>(base));
    if (!g_run.exchange(true)) g_worker = std::thread(workerLoop);
    return true;
}

bool isAttached() { return g_pid.load() != 0 && g_base.load() != 0; }

void setAimEnabled(bool v) { g_cfg.aim = v; }
void setAimParams(float fov, float speed, float range) {
    g_cfg.fov = clampf(fov, 1.f, 180.f);
    g_cfg.speed = clampf(speed, 10.f, 1440.f);
    g_cfg.range = clampf(range, 1.f, 12.f);
}
void setHitboxEnabled(bool v) {
    if (!v) { pid_t pid = g_pid.load(); if (pid) restoreBoxes(pid); }
    g_cfg.hitbox = v;
}
void setHitboxParams(float w, float h) {
    g_cfg.hbW = clampf(w, 0.1f, 4.f);
    g_cfg.hbH = clampf(h, 0.1f, 4.f);
}

void shutdown() {
    g_run = false;
    if (g_worker.joinable()) g_worker.join();
    pid_t pid = g_pid.load();
    if (pid) restoreBoxes(pid);
    g_pid = 0;
    g_base = 0;
}

} // namespace cc
