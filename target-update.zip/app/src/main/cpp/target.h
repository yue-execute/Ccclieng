// Minecraft Bedrock 1.26.60 (Android, arm64-v8a) target data.
//
// kOffPosComponentPtr is the first value this whole effort has actually
// confirmed, via two independent vtable functions found by relocation-
// table parsing (not guesswork): one reads 3 floats from this pointer's
// target (+0x0, +0x4, +0x8 -- x, y, z), the other writes into the SAME
// pointer's target at different sub-offsets (+0x18, +0x20). Position is
// NOT a flat offset on Actor -- it's a pointer to a separate component
// (consistent with Bedrock's EnTT-based entity system), stored at this
// offset on Actor itself.
//
// Everything else below is still unset. In particular: rotation was NOT
// found in LocalPlayer's own vtable (30 entries checked). The gap between
// the position floats (0x0-0xB) and the setter's fields (0x18, 0x20) on
// that same component -- bytes 0xC to 0x17, room for 3 more floats -- is
// a *plausible* place for rotation given Bedrock tracks body yaw, pitch,
// and head yaw separately, but this is a hypothesis from struct shape,
// not a verified offset. Confirm live (e.g. with GameGuardian: read
// floats at component+0xC, +0x10, +0x14 and check if any tracks camera
// direction) before ever setting kOffYaw/kOffPitch to these values.
#pragma once
#include <cstddef>

namespace target {

constexpr size_t kUnset = static_cast<size_t>(-1);
constexpr const char* kGameLib = "libminecraftpe.so";
constexpr const char* kPackage = "com.mojang.minecraftpe";

struct Chain { int n; size_t v[8]; };

constexpr Chain kLocalPlayer = {0, {}};   // still unset -- root not found yet
constexpr Chain kActorList = {0, {}};     // still unset -- root not found yet

// CONFIRMED (static analysis, not yet live-verified): offset of a pointer
// to Actor's position/spatial component. Position = *(float[3]*)(*(Actor+this)+0).
constexpr size_t kOffPosComponentPtr = 0x228;
constexpr size_t kOffPosInComponent = 0x0;   // x,y,z as 3 consecutive floats here
constexpr bool   kPosIsEye = false;

// UNSET -- not found. See the long comment above for the unverified
// hypothesis (component+0xC/+0x10/+0x14) -- do not fill these in from
// that guess; fill them in only once confirmed live.
constexpr size_t kOffYaw = kUnset;
constexpr size_t kOffPitch = kUnset;

constexpr size_t kOffHitW = kUnset;
constexpr size_t kOffHitH = kUnset;
constexpr size_t kOffActorType = kUnset;
constexpr int    kPlayerTypeId = -1;

constexpr float kEyeHeight = 1.62f;

} // namespace target
