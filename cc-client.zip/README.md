# CC Client (Minecraft Bedrock 1.26.60, Android arm64-v8a)

Upload this repo to GitHub. The Actions workflow (.github/workflows/build.yaml)
builds `app-debug.apk`; download it from the run's Artifacts.

## State of the build
- `libcc.so` (inside the APK) holds: hitbox expander, aim assist, health HUD,
  armor durability HUD, config file reader, eglSwapBuffers hook.
- `app/src/main/cpp/target.h` is EMPTY of game data. Every pointer chain and
  struct offset for 1.26.60 must be filled in from your own libminecraftpe.so.
  Until then the HUD reads "target data unresolved" and no feature acts.
- Nothing here has been compiled or run against the game.
- The APK is a stub shell. libcc.so must be loaded INTO the Minecraft process
  (e.g. repackage your own Minecraft APK to System.loadLibrary("cc") at start).
  That patching step is not included.

## Config
See `cc.cfg.example`. Place it as `cc.cfg` in the Minecraft app's files dir.
