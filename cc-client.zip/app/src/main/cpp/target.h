// Minecraft Bedrock 1.26.60 (Android, arm64-v8a) target data.
// EVERY value below is UNSET on purpose: they must be extracted from your own
// libminecraftpe.so for build 1.26.60. Nothing here is guessed.
// A feature whose values are unset stays inactive and the HUD says so.
#pragma once
#include <cstddef>

namespace target {

constexpr size_t kUnset = static_cast<size_t>(-1);
constexpr const char* kGameLib = "libminecraftpe.so";

// Pointer chain: v[0] = RVA (from the module base) of a pointer-sized slot.
// For each following entry: load the pointer stored at the current address,
// then add v[i]. The result is the address of the final field.
// n = 0 means unresolved.
struct Chain { int n; size_t v[8]; };

// Address of the slot that holds the local Player*.
constexpr Chain kLocalPlayer = {0, {}};
// Address of a libc++ std::vector<Actor*> (begin ptr at +0, end ptr at +8).
constexpr Chain kActorList = {0, {}};

// Offsets inside Actor (bytes).
constexpr size_t kOffPos = kUnset;        // float[3] position
constexpr bool   kPosIsEye = false;       // true if kOffPos is the eye position
constexpr size_t kOffYaw = kUnset;        // float, degrees (0 = +Z, grows clockwise from above)
constexpr size_t kOffPitch = kUnset;      // float, degrees (+ = looking down)
constexpr size_t kOffHealth = kUnset;     // float current health
constexpr size_t kOffHealthMax = kUnset;  // float max health
constexpr size_t kOffHitW = kUnset;       // float AABB shape width
constexpr size_t kOffHitH = kUnset;       // float AABB shape height
constexpr size_t kOffActorType = kUnset;  // int32 actor type id (optional filter)
constexpr int    kPlayerTypeId = -1;      // value of kOffActorType for players, -1 = no filter
constexpr size_t kOffArmorSlots = kUnset; // 4 consecutive ItemStack* (helmet..boots)
constexpr size_t kOffItemDamage = kUnset; // int32 inside ItemStack
constexpr size_t kOffItemMaxDamage = kUnset; // int32 inside ItemStack

constexpr float kEyeHeight = 1.62f;       // player eye height above feet

} // namespace target
