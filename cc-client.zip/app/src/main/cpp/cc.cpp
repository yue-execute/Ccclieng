// CC client payload: hitbox expander, aim assist, health + armor durability HUD.
// In-process module. Entry: constructor -> worker thread -> waits for the game
// library -> patches its eglSwapBuffers import -> runs features once per frame.
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <link.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <thread>
#include <unordered_map>
#include <unordered_set>

#include "imgui.h"
#include "backends/imgui_impl_opengl3.h"
#include "target.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "CC", __VA_ARGS__)

namespace {

using namespace target;

// ---------------------------------------------------------------- config
struct Config {
    bool hitbox = false;
    float hbW = 0.9f, hbH = 1.9f;   // expanded AABB width/height (blocks)
    bool aim = false;
    float fov = 30.f;               // degrees, angular distance from current view
    float speed = 240.f;            // max turn rate, degrees per second
    float range = 6.f;              // blocks
    bool hud = true;
};

float clampf(float v, float lo, float hi) { return std::min(std::max(v, lo), hi); }

Config parseConfig(const std::string& path) {
    Config c;
    std::ifstream in(path);
    std::string line;
    while (std::getline(in, line)) {
        auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        float f = static_cast<float>(std::atof(v.c_str()));
        bool b = f != 0.f;
        if (k == "hitbox") c.hitbox = b;
        else if (k == "hitbox_w") c.hbW = clampf(f, 0.1f, 4.f);
        else if (k == "hitbox_h") c.hbH = clampf(f, 0.1f, 4.f);
        else if (k == "aim") c.aim = b;
        else if (k == "aim_fov") c.fov = clampf(f, 1.f, 180.f);
        else if (k == "aim_speed") c.speed = clampf(f, 10.f, 1440.f);
        else if (k == "aim_range") c.range = clampf(f, 1.f, 12.f);
        else if (k == "hud") c.hud = b;
    }
    return c;
}

std::string packageName() {
    char buf[256] = {};
    FILE* f = fopen("/proc/self/cmdline", "r");
    if (!f) return {};
    fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    return buf;
}

// External app dir first (user-editable), internal files dir as fallback.
std::string configPath() {
    std::string pkg = packageName();
    std::string ext = "/storage/emulated/0/Android/data/" + pkg + "/files/cc.cfg";
    if (access(ext.c_str(), R_OK) == 0) return ext;
    return "/data/data/" + pkg + "/files/cc.cfg";
}

// ---------------------------------------------------------------- memory
bool readMem(uintptr_t a, void* out, size_t n) {
    if (!a) return false;
    iovec l{out, n}, r{reinterpret_cast<void*>(a), n};
    return syscall(__NR_process_vm_readv, getpid(), &l, 1, &r, 1, 0) == static_cast<long>(n);
}
template <class T> bool rd(uintptr_t a, T& o) { return readMem(a, &o, sizeof(T)); }

bool wr(uintptr_t a, const void* p, size_t n) {
    char probe;
    if (!readMem(a, &probe, 1) || !readMem(a + n - 1, &probe, 1)) return false;
    std::memcpy(reinterpret_cast<void*>(a), p, n);
    return true;
}

bool resolveAddr(const Chain& c, uintptr_t base, uintptr_t& out) {
    if (c.n <= 0) return false;
    uintptr_t a = base + c.v[0];
    for (int i = 1; i < c.n; i++) {
        uintptr_t p;
        if (!rd(a, p) || !p) return false;
        a = p + c.v[i];
    }
    out = a;
    return true;
}

bool have(size_t off) { return off != kUnset; }

// ---------------------------------------------------------------- game state
struct Vec3 { float x, y, z; };

struct Frame {
    bool ok = false;
    const char* err = "";
    bool hasTarget = false;
    float dist = 0, hp = 0, maxHp = 0;
    bool armorOk = false;
    int armorLeft[4] = {0, 0, 0, 0}, armorMax[4] = {0, 0, 0, 0};
    bool aiming = false;
};

std::unordered_map<uintptr_t, std::pair<float, float>> g_origBox;  // actor -> original w,h

void restoreBoxes() {
    for (auto& [p, wh] : g_origBox) {
        wr(p + kOffHitW, &wh.first, 4);
        wr(p + kOffHitH, &wh.second, 4);
    }
    g_origBox.clear();
}

float wrap180(float d) {
    while (d > 180.f) d -= 360.f;
    while (d < -180.f) d += 360.f;
    return d;
}

Frame update(const Config& cfg, float dt, uintptr_t base) {
    Frame f;
    uintptr_t lpAddr, listAddr;
    if (!resolveAddr(kLocalPlayer, base, lpAddr) || !resolveAddr(kActorList, base, listAddr) ||
        !have(kOffPos)) {
        f.err = "target data unresolved (see target.h)";
        return f;
    }
    uintptr_t lp = 0;
    Vec3 lpos;
    if (!rd(lpAddr, lp) || !lp || !rd(lp + kOffPos, lpos)) { f.err = "no local player"; return f; }
    Vec3 eye = lpos;
    if (!kPosIsEye) eye.y += kEyeHeight;

    uintptr_t b = 0, e = 0;
    if (!rd(listAddr, b) || !rd(listAddr + 8, e) || e < b) { f.err = "actor list unreadable"; return f; }
    size_t count = (e - b) / sizeof(uintptr_t);
    if (count > 1024) { f.err = "actor list implausible"; return f; }
    f.ok = true;

    float curYaw = 0, curPitch = 0;
    bool canAim = cfg.aim && have(kOffYaw) && have(kOffPitch) &&
                  rd(lp + kOffYaw, curYaw) && rd(lp + kOffPitch, curPitch);
    bool canBox = have(kOffHitW) && have(kOffHitH);

    std::unordered_set<uintptr_t> seen;
    uintptr_t bestAim = 0, nearest = 0;
    float bestErr = 1e9f, bestYaw = 0, bestPitch = 0, nearestD = 1e9f;

    for (size_t i = 0; i < count; i++) {
        uintptr_t a;
        if (!rd(b + i * sizeof(uintptr_t), a) || !a || a == lp) continue;
        Vec3 p;
        if (!rd(a + kOffPos, p) || !std::isfinite(p.x + p.y + p.z)) continue;
        if (have(kOffActorType) && kPlayerTypeId >= 0) {
            int32_t t;
            if (!rd(a + kOffActorType, t) || t != kPlayerTypeId) continue;
        }
        if (have(kOffHealth)) {
            float hp;
            if (!rd(a + kOffHealth, hp) || !(hp > 0.f)) continue;
        }
        float dx = p.x - lpos.x, dy = p.y - lpos.y, dz = p.z - lpos.z;
        float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
        seen.insert(a);

        if (cfg.hitbox && canBox && dist <= 16.f) {
            if (!g_origBox.count(a)) {
                float w, h;
                if (rd(a + kOffHitW, w) && rd(a + kOffHitH, h)) g_origBox[a] = {w, h};
            }
            if (g_origBox.count(a)) {
                wr(a + kOffHitW, &cfg.hbW, 4);
                wr(a + kOffHitH, &cfg.hbH, 4);
            }
        }
        if (dist < nearestD) { nearestD = dist; nearest = a; }

        if (canAim && dist <= cfg.range) {
            Vec3 aimPt = p;
            if (!kPosIsEye) aimPt.y += kEyeHeight;
            float tx = aimPt.x - eye.x, ty = aimPt.y - eye.y, tz = aimPt.z - eye.z;
            float hd = std::sqrt(tx * tx + tz * tz);
            if (hd < 1e-4f) continue;
            float yaw = std::atan2(-tx, tz) * 57.29578f;           // 0 = +Z, clockwise
            float pitch = -std::atan2(ty, hd) * 57.29578f;          // + = down
            float ey = wrap180(yaw - curYaw), ep = pitch - curPitch;
            float err = std::sqrt(ey * ey + ep * ep);
            if (err <= cfg.fov && err < bestErr) {
                bestErr = err; bestAim = a; bestYaw = yaw; bestPitch = pitch;
            }
        }
    }

    // Drop records for actors that vanished (freed memory must not be written back).
    for (auto it = g_origBox.begin(); it != g_origBox.end();)
        it = seen.count(it->first) ? std::next(it) : g_origBox.erase(it);

    if (bestAim) {
        float step = cfg.speed * dt;
        float ny = curYaw + clampf(wrap180(bestYaw - curYaw), -step, step);
        float np = curPitch + clampf(bestPitch - curPitch, -step, step);
        wr(lp + kOffYaw, &ny, 4);
        wr(lp + kOffPitch, &np, 4);
        f.aiming = true;
    }

    uintptr_t hud = bestAim ? bestAim : nearest;
    if (hud) {
        Vec3 p;
        rd(hud + kOffPos, p);
        f.hasTarget = true;
        f.dist = std::sqrt((p.x - lpos.x) * (p.x - lpos.x) + (p.y - lpos.y) * (p.y - lpos.y) +
                           (p.z - lpos.z) * (p.z - lpos.z));
        if (have(kOffHealth)) rd(hud + kOffHealth, f.hp);
        if (have(kOffHealthMax)) rd(hud + kOffHealthMax, f.maxHp);
        if (have(kOffArmorSlots) && have(kOffItemDamage) && have(kOffItemMaxDamage)) {
            f.armorOk = true;
            for (int s = 0; s < 4; s++) {
                uintptr_t item = 0;
                int32_t dmg = 0, mx = 0;
                if (rd(hud + kOffArmorSlots + s * sizeof(uintptr_t), item) && item &&
                    rd(item + kOffItemDamage, dmg) && rd(item + kOffItemMaxDamage, mx) && mx > 0) {
                    f.armorMax[s] = mx;
                    f.armorLeft[s] = std::max(0, mx - dmg);
                }
            }
        }
    }
    return f;
}

// ---------------------------------------------------------------- GOT hook
struct HookCtx { const char* lib; const char* sym; void* repl; void* orig; bool done; };

int hookCb(dl_phdr_info* i, size_t, void* d) {
    auto* c = static_cast<HookCtx*>(d);
    if (!i->dlpi_name || !std::strstr(i->dlpi_name, c->lib)) return 0;
    ElfW(Dyn)* dyn = nullptr;
    for (int k = 0; k < i->dlpi_phnum; k++)
        if (i->dlpi_phdr[k].p_type == PT_DYNAMIC)
            dyn = reinterpret_cast<ElfW(Dyn)*>(i->dlpi_addr + i->dlpi_phdr[k].p_vaddr);
    if (!dyn) return 1;
    auto fix = [&](uintptr_t v) { return v < i->dlpi_addr ? i->dlpi_addr + v : v; };  // bionic quirk
    ElfW(Sym)* symtab = nullptr;
    const char* strtab = nullptr;
    ElfW(Rela)* rel[2] = {nullptr, nullptr};
    size_t relsz[2] = {0, 0};
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_SYMTAB: symtab = reinterpret_cast<ElfW(Sym)*>(fix(dyn->d_un.d_ptr)); break;
            case DT_STRTAB: strtab = reinterpret_cast<const char*>(fix(dyn->d_un.d_ptr)); break;
            case DT_JMPREL: rel[0] = reinterpret_cast<ElfW(Rela)*>(fix(dyn->d_un.d_ptr)); break;
            case DT_PLTRELSZ: relsz[0] = dyn->d_un.d_val; break;
            case DT_RELA: rel[1] = reinterpret_cast<ElfW(Rela)*>(fix(dyn->d_un.d_ptr)); break;
            case DT_RELASZ: relsz[1] = dyn->d_un.d_val; break;
        }
    }
    if (!symtab || !strtab) return 1;
    for (int j = 0; j < 2; j++) {
        if (!rel[j]) continue;
        for (size_t k = 0; k < relsz[j] / sizeof(ElfW(Rela)); k++) {
            uint32_t si = ELF64_R_SYM(rel[j][k].r_info);
            if (!si || std::strcmp(strtab + symtab[si].st_name, c->sym) != 0) continue;
            void** slot = reinterpret_cast<void**>(i->dlpi_addr + rel[j][k].r_offset);
            long ps = sysconf(_SC_PAGESIZE);
            void* page = reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(slot) & ~(ps - 1));
            if (mprotect(page, ps, PROT_READ | PROT_WRITE) != 0) continue;
            if (!c->orig) c->orig = *slot;
            *slot = c->repl;
            c->done = true;
        }
    }
    return 1;
}

uintptr_t moduleBase(const char* lib) {
    uintptr_t base = 0;
    struct P { const char* lib; uintptr_t* out; } p{lib, &base};
    dl_iterate_phdr([](dl_phdr_info* i, size_t, void* d) {
        auto* p = static_cast<P*>(d);
        if (i->dlpi_name && std::strstr(i->dlpi_name, p->lib)) { *p->out = i->dlpi_addr; return 1; }
        return 0;
    }, &p);
    return base;
}

// ---------------------------------------------------------------- render hook
using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapFn g_origSwap = nullptr;
uintptr_t g_base = 0;
std::string g_cfgPath;
Config g_cfg;
EGLContext g_ctx = EGL_NO_CONTEXT;
bool g_imguiUp = false;

void imguiDown() {
    if (!g_imguiUp) return;
    ImGui_ImplOpenGL3_Shutdown();
    ImGui::DestroyContext();
    g_imguiUp = false;
}

EGLBoolean hkSwap(EGLDisplay d, EGLSurface s) {
    using clock = std::chrono::steady_clock;
    static auto last = clock::now(), lastCfg = last - std::chrono::seconds(10);
    auto now = clock::now();
    float dt = clampf(std::chrono::duration<float>(now - last).count(), 0.001f, 0.1f);
    last = now;

    if (now - lastCfg > std::chrono::seconds(1)) {
        bool wasBox = g_cfg.hitbox;
        g_cfg = parseConfig(g_cfgPath);
        if (wasBox && !g_cfg.hitbox) restoreBoxes();
        lastCfg = now;
    }

    EGLContext ctx = eglGetCurrentContext();
    if (ctx != g_ctx) { imguiDown(); g_ctx = ctx; }

    Frame fr = update(g_cfg, dt, g_base);

    if (g_cfg.hud && ctx != EGL_NO_CONTEXT) {
        EGLint w = 0, h = 0;
        eglQuerySurface(d, s, EGL_WIDTH, &w);
        eglQuerySurface(d, s, EGL_HEIGHT, &h);
        if (w > 0 && h > 0) {
            if (!g_imguiUp) {
                ImGui::CreateContext();
                ImGui::GetIO().IniFilename = nullptr;
                ImGui_ImplOpenGL3_Init("#version 300 es");
                g_imguiUp = true;
            }
            ImGuiIO& io = ImGui::GetIO();
            io.DisplaySize = ImVec2(static_cast<float>(w), static_cast<float>(h));
            io.DeltaTime = dt;
            io.FontGlobalScale = clampf(h / 720.f, 1.f, 3.f);
            ImGui_ImplOpenGL3_NewFrame();
            ImGui::NewFrame();
            ImGui::SetNextWindowPos(ImVec2(16, 16));
            ImGui::SetNextWindowBgAlpha(0.35f);
            ImGui::Begin("cc", nullptr,
                         ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs |
                             ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings);
            if (!fr.ok) {
                ImGui::Text("CC: %s", fr.err);
            } else if (!fr.hasTarget) {
                ImGui::Text("CC: no target in range");
            } else {
                ImGui::Text("Target %.1fm%s", fr.dist, fr.aiming ? "  [aim]" : "");
                if (have(kOffHealth)) ImGui::Text("HP %.1f / %.1f", fr.hp, fr.maxHp);
                else ImGui::Text("HP: kOffHealth unset");
                if (fr.armorOk) {
                    static const char* n[4] = {"Helmet", "Chest", "Legs", "Boots"};
                    for (int i = 0; i < 4; i++) {
                        if (fr.armorMax[i] > 0)
                            ImGui::Text("%s %d/%d", n[i], fr.armorLeft[i], fr.armorMax[i]);
                        else ImGui::Text("%s -", n[i]);
                    }
                } else {
                    ImGui::Text("Armor: item offsets unset");
                }
            }
            ImGui::End();
            ImGui::Render();
            ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        }
    }
    return g_origSwap(d, s);
}

void worker() {
    for (int i = 0; i < 1200 && !(g_base = moduleBase(kGameLib)); i++) usleep(100 * 1000);
    if (!g_base) { LOG("game library not found; module idle"); return; }
    g_cfgPath = configPath();
    HookCtx c{kGameLib, "eglSwapBuffers", reinterpret_cast<void*>(&hkSwap), nullptr, false};
    // Retry: the import table may not be populated the instant the library appears.
    for (int i = 0; i < 100 && !c.done; i++) {
        dl_iterate_phdr(hookCb, &c);
        if (!c.done) usleep(200 * 1000);
    }
    if (!c.done) { LOG("eglSwapBuffers import not found in %s", kGameLib); return; }
    g_origSwap = reinterpret_cast<SwapFn>(c.orig);
    LOG("hooked eglSwapBuffers, base=%p cfg=%s", reinterpret_cast<void*>(g_base), g_cfgPath.c_str());
}

}  // namespace

__attribute__((constructor)) static void ccInit() { std::thread(worker).detach(); }
