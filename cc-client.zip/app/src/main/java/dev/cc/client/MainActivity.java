package dev.cc.client;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** Stub shell. The payload is libcc.so (see README.md for how it gets into Minecraft). */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setPadding(48, 96, 48, 48);
        t.setText("CC Client\n\nPayload: lib/arm64-v8a/libcc.so\nSee README.md for config and loading.");
        setContentView(t);
    }
}
